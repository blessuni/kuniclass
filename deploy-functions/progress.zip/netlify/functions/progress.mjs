
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/progress.mjs
import { getStore } from "@netlify/blobs";

// server/activity-flow.mjs
var capturedAll = (r) => r.selected.length >= 2 && r.selected.every((v) => r.done.includes(v));
function normalizeFlow(r) {
  const done = r.done.filter((v) => r.selected.includes(v));
  let x = { ...r, done };
  if (!capturedAll(x) && ["captured", "return", "photos", "upload", "finish", "extra"].includes(x.screen)) x = { ...x, screen: done.length ? "oneDone" : "activity", canva: false, uploaded: false };
  if (x.canva && (!capturedAll(x) || x.screen !== "upload")) x.canva = false;
  if (x.screen === "finish" && !x.uploaded) x.screen = capturedAll(x) ? "captured" : "activity";
  return x;
}
function stageOf(r) {
  r = normalizeFlow(r);
  if (r.canva) return "\u{1F3A8} Canva \uC5C5\uB85C\uB4DC";
  if (r.screen === "finish" && r.uploaded) return "\u2728 \uC644\uB8CC";
  if (r.screen === "return") return "\u{1FA91} \uBAA8\uB460 \uC790\uB9AC\uB85C \uC774\uB3D9";
  if (r.screen === "photos") return "\u{1F4F1} \uC0AC\uC9C4 \uD655\uC778";
  if (r.screen === "upload") return "\u{1F3A8} Canva \uC5C5\uB85C\uB4DC";
  if (["confirm", "roles"].includes(r.screen)) return "\u{1F4AC} \uC774\uC57C\uAE30 \uC911";
  if (["activity", "oneDone", "captured", "extra"].includes(r.screen)) return `\u{1F4F7} \uB9C8\uC74C\uBCF4\uC11D \uD45C\uD604 \uC911 (${r.done.length}/${r.selected.length})`;
  return "\u{1F48E} \uC120\uD0DD \uC911";
}

// server/progress-core.mjs
var groups = [["\uD611\uB3D9", "\uCC45\uC784", "\uACBD\uCCAD", "\uAC10\uC0AC"], ["\uBC30\uB824", "\uC9C8\uC11C", "\uACF5\uAC10", "\uC6A9\uAE30"], ["\uACBD\uCCAD", "\uC131\uC2E4", "\uD611\uB3D9", "\uC608\uC758"], ["\uACF5\uAC10", "\uB048\uAE30", "\uBC30\uB824", "\uC790\uC8FC"], ["\uC874\uC911", "\uACBD\uCCAD", "\uACF5\uAC10", "\uD611\uB3D9"]];
var screens = ["select", "confirm", "roles", "activity", "extra", "finish", "return", "photos", "oneDone", "captured", "upload"];
function validate(x) {
  if (!x || typeof x.device !== "string" || !/^[a-zA-Z0-9-]{1,80}$/.test(x.device) || !Number.isInteger(x.group) || x.group < 1 || x.group > 5 || x.record?.group !== x.group) return null;
  const r = x.record;
  const valid = groups[x.group - 1];
  if (!Array.isArray(r.selected) || r.selected.length > 4 || new Set(r.selected).size !== r.selected.length || r.selected.some((v) => !valid.includes(v)) || !Array.isArray(r.done) || new Set(r.done).size !== r.done.length || r.done.some((v) => !r.selected.includes(v)) || !screens.includes(r.screen)) return null;
  if (r.screen === "select" && r.selected.length > 2) return null;
  const record = normalizeFlow({ group: x.group, selected: r.selected, done: r.done, screen: r.screen, extra: valid.includes(r.extra) ? r.extra : null, pending: r.selected.includes(r.pending) ? r.pending : null, role: Number.isInteger(r.role) && r.role >= -1 && r.role < 5 ? r.role : -1, canva: !!r.canva, uploaded: !!r.uploaded });
  const category = x.group === 5 ? "observer" : "child";
  return { id: category + "/" + x.group + "/" + x.device, device_id: x.device, group_id: x.group, category, record_json: JSON.stringify(record), stage: stageOf(record), updated_at: Date.now(), revision: Number.isFinite(x.revision) ? x.revision : Date.now() };
}
async function handleProgress(request, store) {
  const headers = { "Cache-Control": "no-store", "Content-Type": "application/json; charset=utf-8" };
  const reply = (data, status = 200) => new Response(JSON.stringify(data), { status, headers });
  try {
    if (request.method === "GET") {
      const { blobs } = await store.list();
      const values = await Promise.all(blobs.filter((b) => /^(child|observer)\//.test(b.key)).map((b) => store.get(b.key, { type: "json", consistency: "strong" })));
      const rows = values.filter(Boolean).map((row2) => {
        const record = normalizeFlow(JSON.parse(row2.record_json));
        return { ...row2, record_json: JSON.stringify(record), stage: stageOf(record) };
      }).sort((a, b) => b.updated_at - a.updated_at);
      return reply({ rows, serverTime: Date.now(), storage: "netlify-blobs" });
    }
    if (request.method !== "POST") return reply({ error: "\uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC740 \uC694\uCCAD" }, 405);
    if (Number(request.headers.get("content-length") || 0) > 5e3) return reply({ error: "\uAE30\uB85D\uC774 \uB108\uBB34 \uCEE4\uC694" }, 413);
    const body = await request.text();
    if (body.length > 5e3) return reply({ error: "\uAE30\uB85D\uC774 \uB108\uBB34 \uCEE4\uC694" }, 413);
    let input;
    try {
      input = JSON.parse(body);
    } catch {
      return reply({ error: "\uAE30\uB85D \uD615\uC2DD\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694" }, 400);
    }
    const row = validate(input);
    if (!row) return reply({ error: "\uAE30\uB85D \uB0B4\uC6A9\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694" }, 400);
    const old = await store.get(row.id, { type: "json", consistency: "strong" });
    if (old && old.revision > row.revision) return reply({ ok: true, ignoredOlder: true });
    await store.setJSON(row.id, row);
    return reply({ ok: true, updatedAt: row.updated_at });
  } catch (error) {
    console.error("\uB9C8\uC74C\uBCF4\uC11D \uC9C4\uD589\uC0C1\uD669 \uC800\uC7A5 \uC624\uB958", error);
    return reply({ error: "\uC9C4\uD589\uC0C1\uD669 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694" }, 503);
  }
}

// netlify/functions/progress.mjs
async function progress_default(request) {
  try {
    return await handleProgress(request, getStore({ name: "jinju-maeum-progress-v1", consistency: "strong" }));
  } catch (error) {
    console.error("\uC9C4\uD589\uC0C1\uD669 \uC800\uC7A5 \uC5F0\uACB0 \uC624\uB958", error);
    return Response.json({ error: "\uC9C4\uD589\uC0C1\uD669 \uC11C\uBC84 \uC5F0\uACB0\uC744 \uD655\uC778\uD574 \uC8FC\uC138\uC694" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
export {
  progress_default as default
};
